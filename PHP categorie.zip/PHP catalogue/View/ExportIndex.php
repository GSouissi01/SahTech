<?php
    include_once '../Model/Catalog.php';
    include_once '../Controller/ExportCSV.php';
    include '../config.php';
?>
<!-- Export link -->
<div class="col-md-12 head">
    <div class="float-right">
        <a href="ExportCSV.php" class="btn btn-success"><i class="dwn"></i> Export</a>
    </div>
</div>

<!-- Data list table --> 
<!-- Bootstrap library -->
<link rel="stylesheet" href="assets/bootstrap/bootstrap.min.css">

<!-- Stylesheet file -->
<link rel="stylesheet" href="assets/css/style.css">
<table class="table table-striped table-bordered">
    <thead class="thead-dark">
        <tr>
            <th>#ID</th>
            <th>Nom Categorie</th>
            <th>Nombre de produit</th>
            <th>Description</th>
        </tr>
    </thead>
    <tbody>
   <?php 
   include '../config.php';
    // Fetch records from database 
    $db = config::getConnexion();
    $result = $db->query("SELECT * FROM catalogue ORDER BY id ASC"); 
    if($result->num_rows > 0){ 
        while($row = $result->fetch_assoc()){ 
    ?>
        <tr>
            <td><?php echo $row['id']; ?></td>
            <td><?php echo $row['nomCategorie']; ?></td>
            <td><?php echo $row['nbrProd']; ?></td>
            <td><?php echo $row['dscrpt']; ?></td>
        </tr>
    <?php } }else{ ?>
        <tr><td colspan="7">No member(s) found...</td></tr>
    <?php } ?>
    </tbody>
</table>