<?php
include_once '../config.php';
include '../View/fpdf.php';
$db = config::getConnexion();

$pdf = new FPDF();
$pdf->AddPage();
 
$pdf->SetFont('Arial','B',12);	
$ret ="SELECT `COLUMN_NAME` FROM `INFORMATION_SCHEMA`.`COLUMNS` 
WHERE `TABLE_SCHEMA`='database_name' AND `TABLE_NAME`='catalogue'";
$query1 = $db -> prepare($ret);
$query1->execute();
$header=$query1->fetchAll(PDO::FETCH_OBJ);
$cnt=1;
if($query1->rowCount() > 0)
{
foreach($header as $heading) {
foreach($heading as $column_heading)
$pdf->Cell(39,12,$column_heading,1);
}}
//code for print data
$sql = "SELECT * from  catalogue";
$query = $db -> prepare($sql);
$query->execute();
$results=$query->fetchAll(PDO::FETCH_OBJ);
$cnt=1;
if($query->rowCount() > 0)
{
foreach($results as $row) {
$pdf->SetFont('Arial','',10);	
$pdf->Ln();
foreach($row as $column)
$pdf->Cell(39,7,$column,1);
} }
$pdf->Output();
?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.1.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <!-- <link rel="stylesheet" href="C:\xampp\htdocs\Medicio\PHP catalogue\View\fpdf.css"> -->
    <title>Catégories</title>
</head>
    <body>
        <button><a href="AfficherCatalog.php">Retour à la liste des catégories</a></button>
        <hr>
        
        <!-- <div id="error">
            <?php echo $error; ?>
        </div> -->
    <div class="card-header">
        <form action="generatePDF_categorie.php" method="POST">
            <button type="submit" class="btn btn-success">PDF</buton>
        </form>
</div>
            <table border="1" align="center">
                <tr>
                    <td>
                        <label for="ref">ID:
                        </label>
                    </td>
                    <td><input type="number" name="id" id="id" maxlength="20"></td>
                </tr>
				<tr>
                    <td>
                        <label for="nomcategories">Nom de la catégorie:
                        </label>
                    </td>
                    <td>
                        <input type="text" name="nomCategorie" id="nomcategorie" maxlength="60" ></td>
                </tr>
                <tr>   
                    <td>
                        <label for="nbrprod">Nombre de produits:
                        </label>
                    </td>
                    <td>
                        <input type="number" name="nbrProd" id="nbrprod" maxlength="20" min=0></td>
                </tr>
                <tr>
                    <td>
                        <label for="dscrpt">Description:
                        </label>
                    </td>
                    <td>
                        <input type="text" name="dscrpt" id="dscrpt">
                    </td>
                </tr>
                <tr>
                    <td></td>
                    <td>
                        <input type="submit" value="Envoyer"> 
                    </td>
                    <td>
                        <input type="reset" value="Annuler" >
                    </td>
                </tr>
            </table>
        </form>
    </body>
</html>