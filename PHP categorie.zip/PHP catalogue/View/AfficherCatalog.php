<?php
	require_once '../Controller/CatalogC.php';
	$catalogc=new CatalogC();
	$listeCatalogue=$catalogc->affichercatalog(); 
?>
<html>
	<head>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.1.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
	</head>
	<body>
	    <button><a href="AjouterCatalog.php">Ajouter une catégorie</a></button>
		<center><h1>Liste des catégories</h1></center>
		<table border="1" align="center">
			<tr>
				<th>Id</th>
				<th>Nom catégorie</th>
				<th>Nombre de produits</th>
				<th>Description catégorie</th>
			</tr>
			<?php
				foreach($listeCatalogue as $catal){
			?>
			<tr>
				<td><?php echo $catal['id']; ?></td>
				<td><?php echo $catal['nomCategorie']; ?></td>
				<td><?php echo $catal['nbrProd']; ?></td>
				<td><?php echo $catal['dscrpt']; ?></td>
				<td>
					<form method="POST" action="ModifierCatalog.php">
						<input type="submit" name="Modifier" value="Modifier">
						<input type="hidden" value="<?php echo $catal['id']; ?>" name="id">
					</form>
				</td>
				<td>
					<a href="SupprimerCatalog.php? id=<?php echo $catal['id']; ?>">Supprimer</a>
				</td>
			</tr>
			<?php
				}
			?>
		</table>
	</body>
</html>