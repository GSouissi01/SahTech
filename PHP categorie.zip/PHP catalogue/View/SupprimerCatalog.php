<?php
	include '../Controller/CatalogC.php';
	$catalogc=new CatalogC();
	$catalogc->supprimercatalog($_GET['id']);
	//$equipC=$equipC->afficherequip(); 
	header('Location:AfficherCatalog.php');
?>