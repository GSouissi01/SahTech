<?php
    require_once '../Model/Catalog.php';
    require_once '../Controller/CatalogC.php';
    // ini_set('display_errors',1);
    // error_reporting(E_ALL);
    $error = "";

    // create adherent
    $catalog = null;

    // create an instance of the controller
    $catalogc = new CatalogC();
    if (
        isset($_POST['id']) &&
        isset($_POST['nomCategorie']) &&
		isset($_POST['nbrProd']) &&		
        isset($_POST['dscrpt']) 
    ) {
        if (
            !empty($_POST['id']) && 
            !empty($_POST['nomCategorie']) &&
			!empty($_POST['nbrProd']) &&
            !empty($_POST['dscrpt']) 
        ) {
            $catalog = new Catalog(
                $_POST['id'],
                $_POST['nomCategorie'],
				$_POST['nbrProd'],
                $_POST['dscrpt']

            );
            //print_r($catalog);
            $catalogc->modifiercatalog($catalog, $_POST['id']);
            //print_r($catalogc);
            header('Location:AfficherCatalog.php');
        }
        else
            $error = "!!!";
    }    
?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.1.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <title>Front</title>
</head>
    <body>
        <button><a href="AfficherCatalog.php">Retour à la liste des catalogues</a></button>
        <hr>
        
        <div id="error">
            <?php echo $error; ?>
        </div>
		<?php
			if (isset($_POST['id'])){
				$catalog = $catalogc->recuperercatalog($_POST['id']);		
		?>
        
        <form action="" method="POST">
            <table border="1" align="center">
                <tr>
                    <td>
                        <label for="id">ID:
                        </label>
                    </td>
                    <td><input type="number" name="id" id="id" value="<?php echo $catalog['id']; ?>" maxlength="20"></td>
                </tr>
                <tr>
                    <td>
                        <label for="nomcategorie">Nom Catégorie:
                        </label>
                    </td>
                    <td><input type="text" name="nomCategorie" id="nomcategorie" value="<?php echo $catalog['nomCategorie']; ?>" maxlength="60"></td>
                </tr>
				<tr>
                    <td>
                        <label for="nbrProd">Nombre de produits:
                        </label>
                    </td>
                    <td><input type="number" name="nbrProd" id="nbrProd" value="<?php echo $catalog['nbrProd']; ?>" maxlength="60"></td>
                </tr>
                <tr>
                    <td>
                        <label for="dscrpt">Description:
                        </label>
                    </td>
                    <td><input type="text" name="dscrpt" id="dscrpt" value="<?php echo $catalog['dscrpt']; ?>" maxlength="60"></td>
                </tr>
                <tr>
                    <td></td>
                    <td>
                        <input type="submit" value="Modifier"> 
                    </td>
                    <td>
                        <input type="reset" value="Annuler" >
                    </td>
                </tr>
            </table>
        </form>
		<?php
            }
		?>
    </body>
</html>