<?php
	class Catalog{
		private $id=null;
		private $nomCategorie=null;
		private $nbrProd=null;
		private $dscrpt=null;
		//private $password=null;
		function __construct($id, $nomCategorie, $nbrProd, $dscrpt){
			$this->id=$id;
			$this->nomCategorie=$nomCategorie;
			$this->nbrProd=$nbrProd;
			$this->dscrpt=$dscrpt;
		}
		function getId(){
			return $this->id;
		}
		function getCateg(){
			return $this->nomCategorie;
		}
		function getNbr(){
			return $this->nbrProd;
		}
		function getDescpt(){
			return $this->dscrpt;
		}
        function setId(int $id){
			$this->id =$id; 
        }
		function setCateg(string $nomCategorie){
			$this->nomCategorie=$nomCategorie;
		}
		function setNbr(int $nbrProd){
			$this->nbrProd=$nbrProd;
		}
        function setDescpt(string $dscrpt){
			$this->dscrpt =$dscrpt;
        }
		
	}
?>