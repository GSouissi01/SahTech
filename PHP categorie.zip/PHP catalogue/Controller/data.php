<?php
require_once '../config.php';
$stmt = $db->prepare('select * from catalogue');
$stmt->execute();
$results = $stmt->fetchAll(PDO::FETCH_OBJ);
echo json_encode($results);
?>