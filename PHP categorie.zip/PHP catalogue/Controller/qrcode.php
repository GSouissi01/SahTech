<?php
include('phpqrcode/qrlib.php'); //On inclut la librairie au projet
$lien='http://localhost/Medicio/PHP%20catalogue/View/Read.php'; // Vous pouvez modifier le lien selon vos besoins
QRcode::png($lien, 'image-qrcode.png'); // On crée notre QR Code
?>
