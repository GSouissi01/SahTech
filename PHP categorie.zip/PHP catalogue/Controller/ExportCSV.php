<?php 
 
// Load the database configuration file 
include_once '../config.php'; 
$db = config::getConnexion();
// Fetch records from database 
$query = $db->query("SELECT * FROM catalogue ORDER BY id ASC"); 
//$num_rows=$db->query("SELECT COUNT(*) FROM catalogue");
if($db->query("SELECT COUNT(*) FROM catalogue") > 0){ 
    $delimiter = ","; 
    $filename = "members-data_" . date('Y-m-d') . ".csv"; 
     
    // Create a file pointer 
    $f = fopen('php://memory', 'w'); 
     
    // Set column headers 
    $fields = array('ID', 'NOM CATALOGUE', 'NBR PROD', 'DESCRIPTION'); 
    fputcsv($f, $fields, $delimiter); 
     
    // Output each row of the data, format line as csv and write to file pointer 
    while($row = $query->fetch_assoc()){ 
        $lineData = array($row['id'], $row['nomCategorie'], $row['nbrProd'], $row['dscrpt']); 
        fputcsv($f, $lineData, $delimiter); 
    } 
     
    // Move back to beginning of file 
    fseek($f, 0); 
     
    // Set headers to download file rather than displayed 
    header('Content-Type: text/csv'); 
    header('Content-Disposition: attachment; filename="' . $filename . '";'); 
     
    //output all remaining data on a file pointer 
    fpassthru($f); 
} 
exit; 
 
?>