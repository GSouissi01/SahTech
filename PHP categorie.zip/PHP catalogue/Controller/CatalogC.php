<?php
	include '../config.php';
	include_once '../Model/Catalog.php';
	class CatalogC {
		function affichercatalog(){
			$sql="SELECT * FROM catalogue";
			$db = config::getConnexion();
			try{
				$listeCatalogue = $db->query($sql);
				return $listeCatalogue;
			}
			catch(Exception $e){
				die('Erreur:'. $e->getMessage());
			}
		}
		function supprimercatalog($id){
			$sql="DELETE FROM catalogue WHERE id=:id";
			$db = config::getConnexion();
			$req=$db->prepare($sql);
			$req->bindValue(':id', $id,PDO::PARAM_STR);
			try{
				$req->execute();
			}
			catch(Exception $e){
				die('Erreur:'. $e->getMessage());
			}
		}
		function ajoutercatalog($catalogue){
			$sql="INSERT INTO catalogue (id,nomCategorie, nbrProd, dscrpt) 
			VALUES (:id, :nomCategorie, :nbrProd, :dscrpt)";
			$db = config::getConnexion();
			try{
				$query = $db->prepare($sql);
				$query->execute([
					'id' => $catalogue->getId(),
					'nomCategorie' => $catalogue->getCateg(),
					'nbrProd' => $catalogue->getNbr(),
					'dscrpt' => $catalogue->getDescpt()
				]);			
			}
			catch (Exception $e){
				echo 'Erreur: '.$e->getMessage();
			}			
		}
		function recuperercatalog($id){
			$sql="SELECT * from catalogue where id=$id";
			$db = config::getConnexion();
			try{
				$query=$db->prepare($sql);
				$query->execute();
				$catalog=$query->fetch();
				return $catalog;
			}
			catch (Exception $e){
				die('Erreur: '.$e->getMessage());
			}
		}
		
		function modifiercatalog($catalogc, $id){
			try {
				$db = config::getConnexion();
				$query = $db->prepare(
					'UPDATE catalogue SET 
						nomCategorie= :nomCategorie,
						nbrProd= :nbrProd,
						dscrpt= :dscrpt
					WHERE id= :id'
				);
				$query->execute([
					'nomCategorie' => $catalogc->getCateg(),
					'nbrProd' => $catalogc->getNbr(),
					'dscrpt' => $catalogc->getDescpt(),
					'id' => $id
				]);
				echo $query->rowCount() . " records UPDATED successfully <br>";
			} catch (PDOException $e) {
				$e->getMessage();
			}
		}
		

	}
?>